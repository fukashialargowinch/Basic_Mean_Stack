'use strict';

(function() {

  class MoviesComponent {
    constructor($http, $scope, socket) {
      this.$http = $http;
      this.socket = socket;
      this.$scope = $scope;

      this.MovieData = [];

      $scope.$on('$destroy', function() {
        socket.unsyncUpdates('moviesendpoint');
      });
    }

    $onInit() {
      this.$http.get('/api/moviesendpoints').then(response => {
        this.MovieData = response.data;
        this.socket.syncUpdates('moviesendpoint', this.MovieData);
      });
    }

    addMovie() {
      this.$http.post('/api/moviesendpoints', {
        MovieName: this.MovieName,
        Year: this.Year,
        Genre: this.Genre
      });
    }

    removeMovie(Movie) {
      var x = confirm('Are you sure you want to delete this record ?');
      if (x) {
        this.$http.delete('/api/moviesendpoints/' + Movie._id);
      }
    }

  }

  angular.module('yeomanAppApp')
    .component('movies', {
      templateUrl: 'app/movies/movies.html',
      controller: MoviesComponent,
      controllerAs: 'moviesCtrl'
    });

})();
